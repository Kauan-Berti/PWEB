var express = require('express');
var texto = require('./modulo1');

var app = express(); //executando o express

app.set('view engine', 'ejs');
app.set('views', './app/views');

module.exports = app;