var nome = prompt("Qual é o seu nome?");
var nota1 = prompt("Digite a primeira nota");
var nota2 = prompt("Digite a segunda nota");
var nota3 = prompt("Digite a terceira nota");

media = ((parseFloat(nota1)) + (parseFloat(nota2)) + (parseFloat(nota3))/3).toFixed(2);
alert("A média do aluno " + nome + "Media ="+ media);